public class Animal implements AccionGeneral{
    public String hablar() {
        return "Este animal hace ";
    }

    public String desplazarse() {
        return "Este animal se desplza en sus cuatro patas ";
    }

    public String dormir() {
        return "Este animal está descansando ";
    }
}
