public interface AccionGeneral {
    public String hablar();
    public String desplazarse();
    public String dormir();
}
