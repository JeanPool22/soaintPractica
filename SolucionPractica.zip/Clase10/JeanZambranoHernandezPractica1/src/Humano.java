public class Humano implements AccionGeneral, AccionesHumano {
    public String hablar() {
        return "Hola estoy hablando ";
    }

    public String desplazarse() {
        return "Me estoy desplazando ";
    }

    public String dormir() {
        return "Hora de dormir, Zzzzzzz ";
    }

    public String bailar() {
        return "Es hora de mover el cuerpo ";
    }

    public String estudiar() {
        return "Debo estudiar programación ";
    }

    public String trabajar() {
        return "Hay que hacer dinero ";
    }
}
