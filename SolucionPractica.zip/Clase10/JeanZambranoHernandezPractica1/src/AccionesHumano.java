public interface AccionesHumano {
    public String bailar();
    public String estudiar();
    public String trabajar();
}
